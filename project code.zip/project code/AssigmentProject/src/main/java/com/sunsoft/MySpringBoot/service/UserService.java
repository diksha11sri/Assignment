package com.sunsoft.MySpringBoot.service;

import com.sunsoft.MySpringBoot.entity.User;

public interface UserService {

	String register(User userEntityObj);

	String login(User userEntityObj);

}
