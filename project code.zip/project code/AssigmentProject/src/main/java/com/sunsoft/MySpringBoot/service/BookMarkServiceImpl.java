package com.sunsoft.MySpringBoot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.MySpringBoot.entity.BookMark;
import com.sunsoft.MySpringBoot.repository.BookMarkDAO;

@Service
public class BookMarkServiceImpl implements BookMarkService {

	@Autowired
	BookMarkDAO bd;
	
	public BookMark create(BookMark bm) {
		
		return bd.save(bm);
		
	}

	public BookMark getBookmarkById(String bookmarkId) {
		
		return bd.findBySubfolderId(bookmarkId);
	}

	public void delete(String  bookmarkId) {
		bd.deleteBySubfolderId(bookmarkId);


	}

	

}
