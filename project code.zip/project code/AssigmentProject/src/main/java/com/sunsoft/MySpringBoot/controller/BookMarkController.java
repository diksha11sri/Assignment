package com.sunsoft.MySpringBoot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.sunsoft.MySpringBoot.entity.BookMark;
import com.sunsoft.MySpringBoot.service.BookMarkServiceImpl;

@RestController()
	public class BookMarkController {

	@Autowired
	BookMarkServiceImpl bookmarkService;
		
	@PostMapping("/add")
	public int createNewBookmark(@RequestBody BookMark bm)
	{
		bookmarkService.create(bm);
		System.out.print(bm.toString());
		return bm.getBookmarkId();
		
	}
	
	@PostMapping("/add/{BookmarkId}")
	public int createBookmark(@PathVariable("BookmarkId") String BookmarkId, @RequestBody BookMark bm)
	{
		bm.setSubfolderId(BookmarkId);
		bookmarkService.create(bm);
		System.out.print(bm.toString());
		return bm.getBookmarkId();
		
	}
	
	@PutMapping("/add/{BookmarkId}")
	public int updateBookmark(@PathVariable("BookmarkId") int BookmarkId, @RequestBody BookMark bm)
	{
		bm.setBookmarkId(BookmarkId);
		bookmarkService.create(bm);
		System.out.print(bm.toString());
		return bm.getBookmarkId();
		
	}
	
	@GetMapping("/{BookmarkId}")  
	private BookMark getBookMark(@PathVariable("BookmarkId") String BookmarkId)   
	{  
	return bookmarkService.getBookmarkById(BookmarkId);  
	} 
	
	@DeleteMapping("/{BookmarkId}")  
	private void deleteBook(@PathVariable("BookmarkId") String BookmarkId)   
	{  
		bookmarkService.delete(BookmarkId); 

	
	} 
}