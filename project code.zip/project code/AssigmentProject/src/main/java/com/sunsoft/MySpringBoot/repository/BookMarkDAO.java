package com.sunsoft.MySpringBoot.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.sunsoft.MySpringBoot.entity.BookMark;


@Repository
public interface BookMarkDAO extends JpaRepository<BookMark, Integer> {

	@Query("SELECT s FROM BookMark s WHERE s.subfolderId=?1")
    BookMark findBySubfolderId(String bookmarkId);
	
	@Transactional
	  @Modifying
	    @Query("delete from BookMark b WHERE b.subfolderId = ?1 or BookmarkId = ?1")
	    void deleteBySubfolderId(String bookmarkId);


}
