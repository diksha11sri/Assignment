package com.sunsoft.MySpringBoot.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.sunsoft.MySpringBoot.entity.User;
import com.sunsoft.MySpringBoot.service.UserService;
import com.sunsoft.MySpringBoot.service.UserServiceImpl;




@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
		
@PostMapping("/register")
	public boolean register(@RequestBody User userEntityObj){
		boolean flag = false;
		try {
			if(userService.register(userEntityObj)=="User Registered successfully")
				flag = true;
			else
				flag = false;
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
@PostMapping("/login")
public ResponseEntity<String> login(@RequestBody User userEntityObj){
		return new ResponseEntity<String>(userService.login(userEntityObj),HttpStatus.OK);
	}
}
