package com.sunsoft.MySpringBoot.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.sunsoft.MySpringBoot.entity.User;

public interface UserDAO extends JpaRepository<User, Integer>{


}
