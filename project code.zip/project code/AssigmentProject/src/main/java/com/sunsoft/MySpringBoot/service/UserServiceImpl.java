package com.sunsoft.MySpringBoot.service;

import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sunsoft.MySpringBoot.entity.User;
import com.sunsoft.MySpringBoot.repository.UserDAO;


@Service
public class UserServiceImpl implements UserService {	
	
	@Autowired
	private UserDAO userdao;
	

	public String register(User user) {

			userdao.save(user);
			return "User Registered successfully";

	}

	public String login(User user) {
		
		String msg = "Login Successful";
		
		try
		{
		User userEntity = userdao.findById(user.getUserId()).get();
	
		if(!user.getPassword().equals(userEntity.getPassword()))
			msg="Invalid Password";
		 
			return msg;
		}
		catch (NoSuchElementException ex)
		{
			return "Invalid UserId";
		}
	}
}
