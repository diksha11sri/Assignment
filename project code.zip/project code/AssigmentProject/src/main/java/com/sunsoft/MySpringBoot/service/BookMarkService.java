package com.sunsoft.MySpringBoot.service;

import org.springframework.stereotype.Service;

import com.sunsoft.MySpringBoot.entity.BookMark;

@Service
public interface BookMarkService {
	
	public BookMark create(BookMark bm);
	
//	public BookMark getBookmarkById(int bookmarkId);
//
//	public Iterable<BookMark> findAll();\
	public void delete(String  bookmarkId) ;

}
