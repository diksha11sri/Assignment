package com.sunsoft.MySpringBoot.entity;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity(name="BookMark")
public class BookMark {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int BookmarkId;
	
    @NotBlank(message = "URL is mandatory")
	String url;
	
    @NotBlank(message = "Title is mandatory")
	String title;
	
    @NotBlank(message = "Folder is mandatory")
	String folder;
	
	 String subfolderId;
	 
	String imageUrl;
	
    @NotNull(message = "Date is mandatory")
	@JsonFormat(pattern="yyyy-MM-dd")
	Date date;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getBookmarkId() {
		return BookmarkId;
	}
	public void setBookmarkId(int bookmarkId) {
		BookmarkId = bookmarkId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = folder;
	}
	public String getSubfolderId() {
		return subfolderId;
	}
	public void setSubfolderId(String subfolderId) {
		this.subfolderId = subfolderId;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	@Override
	public String toString() {
		return "BookMark [BookmarkId=" + BookmarkId + ", url=" + url + ", title=" + title + ", folder=" + folder
				+ ", subfolderId=" + subfolderId + ", imageUrl=" + imageUrl + ", date=" + date + "]";
	}
	public BookMark(int bookmarkId, String url, String title, String folder, String subfolderId, String imageUrl,
			Date date) {
		super();
		BookmarkId = bookmarkId;
		this.url = url;
		this.title = title;
		this.folder = folder;
		this.subfolderId = subfolderId;
		this.imageUrl = imageUrl;
		this.date = date;
	}
	public BookMark() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	

}
